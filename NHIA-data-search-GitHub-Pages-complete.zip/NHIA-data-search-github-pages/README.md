# 特材前5碼及診療項目申報量資料庫

這是從 ChatGPT Sites 第 25 版轉換而成的 GitHub Pages 靜態版。所有搜尋、篩選、年度切換、趨勢圖、CAGR、未來申報量推估、多選與 CSV 匯出均在瀏覽器內執行，不需要伺服器或資料庫。

## 內容

- `src/App.tsx`：完整 React 網站功能
- `src/styles.css`：完整網站樣式
- `src/data/materials.json`：健保特材前五碼年度資料
- `src/data/medical-orders.json`：診療項目醫令年度資料
- `public/sources/`：103–114 年特材原始 PDF
- `.github/workflows/deploy.yml`：GitHub Pages 自動部署
- `legacy-sites-source/`：轉換前的完整 Sites 原始碼備份

## 本機執行

請先安裝 Node.js 22 或更新版本，接著執行：

```bash
npm install
npm run dev
```

正式建置及驗證：

```bash
npm test
```

建置完成的網站位於 `dist/`。

## 部署至 GitHub Pages

1. 在 GitHub 建立新的 repository，例如 `nhia-data-search`。
2. 將本資料夾內的所有檔案上傳到 repository 根目錄，不要只上傳 `dist`。
3. 確認預設分支名稱為 `main`。
4. 開啟 repository 的 `Settings` → `Pages`。
5. 在 `Build and deployment` 的 `Source` 選擇 `GitHub Actions`。
6. 前往 `Actions` 頁面查看 `Deploy to GitHub Pages` 工作流程。
7. 部署完成後，網址通常為：

   `https://你的GitHub帳號.github.io/nhia-data-search/`

之後每次更新 `main` 分支，GitHub 都會自動重新建置及發布。

## 資料更新

更新年度資料時，修改以下 JSON 後重新推送即可：

- `src/data/materials.json`
- `src/data/medical-orders.json`

若要重新由原始資料產生 JSON，可參考 `legacy-sites-source/scripts/` 內的擷取程式。

## 權限與搜尋引擎

此版本已加入 `noindex` 與 `robots.txt`，降低搜尋引擎收錄機率，但一般 GitHub Pages 網址仍是公開的。若需要真正限制使用者，應部署至具登入權限控管的 SharePoint、GitHub Enterprise Pages 或其他支援身分驗證的主機。
