# 匯出內容清單

匯出日期：2026-11-10

## GitHub Pages 版本

- React 19 + TypeScript + Vite
- `src/App.tsx`：搜尋、篩選、年度切換、圖表、CAGR、推估與 CSV 匯出
- `src/styles.css`：完整網站樣式
- `src/data/materials.json`：特材 103–114 年資料，共 5,574 筆年度紀錄、640 個前五碼類別
- `src/data/medical-orders.json`：診療項目 105–114 年（2016–2025），共 46,693 筆年度紀錄、5,042 個代碼
- `public/sources/`：103–114 年特材原始 PDF
- `dist/`：已建置完成的靜態網站
- `.github/workflows/deploy.yml`：GitHub Pages 自動建置與部署流程

## 原始 Sites 版本

`legacy-sites-source/` 保存轉換前的完整網站原始碼、資料與擷取程式，供日後追溯或重新轉換。

## 驗證結果

- TypeScript 型別檢查：通過
- Vite production build：通過
- GitHub Pages 相對路徑設定：通過
- 特材查詢與圖表：通過
- 診療項目查詢與圖表：通過
- 民國／西元切換：通過
- 年度區間與 CAGR：通過
- 多選與 CSV 匯出：通過
- 103 與 114 年來源 PDF：通過

部署步驟請見 `README.md`。
