import { access, readdir, readFile, stat } from "node:fs/promises";
import path from "node:path";

const root = process.cwd();
const dist = path.join(root, "dist");

async function requireFile(relativePath) {
  const absolutePath = path.join(dist, relativePath);
  await access(absolutePath);
  return absolutePath;
}

await requireFile("index.html");
await requireFile("favicon.svg");
await requireFile("og.png");
await requireFile("sources/103.pdf");
await requireFile("sources/114.pdf");

const assetDirectory = path.join(dist, "assets");
const assetNames = await readdir(assetDirectory);
const javascriptFiles = assetNames.filter((name) => name.endsWith(".js"));
const cssFiles = assetNames.filter((name) => name.endsWith(".css"));

if (!javascriptFiles.length || !cssFiles.length) {
  throw new Error("建置結果缺少 JavaScript 或 CSS 檔案");
}

const javascript = (
  await Promise.all(
    javascriptFiles.map((name) => readFile(path.join(assetDirectory, name), "utf8")),
  )
).join("\n");

for (const marker of [
  "CBB01",
  "33110B",
  "特材前5碼申報數量資料庫",
  "診療項目醫令申報量資料庫",
  "健保署資料開放平台",
]) {
  if (!javascript.includes(marker)) {
    throw new Error(`建置結果缺少必要資料或功能標記：${marker}`);
  }
}

const totalJavaScriptBytes = (
  await Promise.all(
    javascriptFiles.map(async (name) => (await stat(path.join(assetDirectory, name))).size),
  )
).reduce((sum, size) => sum + size, 0);

if (totalJavaScriptBytes < 1_000_000) {
  throw new Error("JavaScript 建置檔案過小，可能未包含完整資料");
}

console.log(
  `Verified GitHub Pages build: ${javascriptFiles.length} JS, ${cssFiles.length} CSS, ${totalJavaScriptBytes} JS bytes.`,
);
