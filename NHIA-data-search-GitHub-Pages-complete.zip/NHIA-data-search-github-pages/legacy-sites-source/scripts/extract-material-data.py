#!/usr/bin/env python3
"""Extract annual NHIA five-character material-category usage from PDF tables."""

from __future__ import annotations

import argparse
import json
import re
from collections import defaultdict
from pathlib import Path

import pdfplumber


KNOWN_EXPECTED_COUNTS = {
    103: 382,
    104: 372,
    105: 430,
    106: 454,
    107: 471,
    108: 475,
    109: 484,
    110: 486,
    111: 491,
    112: 505,
    113: 508,
}
MATERIAL_CODE_PATTERN = re.compile(r"(?=[A-Z0-9]{5}$)(?=.*[A-Z])[A-Z0-9]{5}")
TABLE_SETTINGS = {
    "vertical_strategy": "lines",
    "horizontal_strategy": "lines",
    "intersection_tolerance": 5,
}


def compact(value: str | None) -> str:
    return " ".join((value or "").replace("\n", " ").split())


def parse_integer(value: str | None) -> int:
    text = compact(value)
    if not text or text in {"-", "–", "—"}:
        return 0
    matches = re.findall(r"\d[\d,]*", text)
    if not matches:
        raise ValueError(f"No numeric value found in {value!r}")
    return int(matches[-1].replace(",", ""))


def looks_like_clean_number(value: str | None) -> bool:
    return bool(re.fullmatch(r"\s*(?:-|[\d,]+)\s*", value or ""))


def name_quality(name: str) -> tuple[int, int]:
    quote_count = name.count('"')
    balanced_quotes = int(quote_count == 0 or quote_count % 2 == 0)
    return balanced_quotes, len(name)


def discover_year_pdfs(source_dir: Path) -> dict[int, Path]:
    pdfs: dict[int, Path] = {}
    for pdf_path in source_dir.glob("*.pdf"):
        match = re.match(r"(\d{3})年(?:度)?.*\.pdf$", pdf_path.name)
        if match:
            year = int(match.group(1))
            if year in pdfs:
                raise ValueError(
                    f"Multiple PDF files found for ROC year {year}: "
                    f"{pdfs[year].name!r} and {pdf_path.name!r}"
                )
            pdfs[year] = pdf_path
    if not pdfs:
        raise ValueError(f"No ROC-year PDFs found in {source_dir}")
    return dict(sorted(pdfs.items()))


def parse_legacy_row(row: list[str | None], year: int) -> tuple[str, str, int, list[str]] | None:
    flat = compact(" ".join(cell or "" for cell in row))
    prefix = rf"{year}(?:年)?\s+"
    code = r"((?=[A-Z0-9]{5}\b)(?=[A-Z0-9]*[A-Z])[A-Z0-9]{5})"
    with_quantity = re.fullmatch(prefix + code + r"\s+(.+?)\s+([\d,]+|-)", flat)
    if with_quantity:
        return (
            with_quantity.group(1),
            compact(with_quantity.group(2)),
            parse_integer(with_quantity.group(3)),
            [],
        )

    without_quantity = re.fullmatch(prefix + code + r"\s+(.+)", flat)
    if without_quantity:
        return (
            without_quantity.group(1),
            compact(without_quantity.group(2)),
            0,
            ["blank_quantity_as_zero"],
        )
    return None


def extract_year(pdf_path: Path, year: int, prior_names: dict[str, str]) -> list[dict]:
    records: list[dict] = []
    with pdfplumber.open(pdf_path) as pdf:
        for page_number, page in enumerate(pdf.pages, start=1):
            tables = page.extract_tables(TABLE_SETTINGS)
            if len(tables) > 1:
                raise ValueError(
                    f"Expected at most one table on {pdf_path.name} page {page_number}; "
                    f"found {len(tables)}"
                )
            for row in tables[0] if tables else []:
                code_index = next(
                    (
                        index
                        for index, cell in enumerate(row)
                        if MATERIAL_CODE_PATTERN.fullmatch(compact(cell))
                    ),
                    None,
                )
                flags: list[str] = []
                if code_index is not None and code_index + 2 < len(row):
                    code = compact(row[code_index])
                    name = compact(row[code_index + 1])
                    quantity_cells = row[code_index + 2 :]
                    sequence_text = compact(row[code_index - 1]) if code_index else ""
                    sequence = int(sequence_text) if sequence_text.isdigit() else None
                    total = parse_integer(quantity_cells[-1])

                    if len(quantity_cells) >= 3:
                        female = parse_integer(quantity_cells[-2])
                        male_cell = quantity_cells[-3]
                        if looks_like_clean_number(male_cell):
                            male = parse_integer(male_cell)
                        else:
                            male = total - female
                            name = prior_names.get(code, name)
                            flags.append("layout_overflow_resolved")
                        if male + female != total:
                            flags.append("published_total_mismatch")
                    else:
                        male = female = None
                else:
                    legacy = parse_legacy_row(row, year)
                    if legacy is None:
                        continue
                    code, name, total, flags = legacy
                    sequence = None
                    male = female = None

                if not re.fullmatch(r"[A-Z0-9]{5}", code):
                    flags.append("invalid_code_format")

                records.append(
                    {
                        "id": f"{year}-{code}",
                        "rocYear": year,
                        "calendarYear": year + 1911,
                        "sequence": sequence,
                        "code": code,
                        "name": name,
                        "maleQuantity": male,
                        "femaleQuantity": female,
                        "totalQuantity": total,
                        "sourceFile": pdf_path.name,
                        "sourcePage": page_number,
                        "flags": flags,
                    }
                )
    if records and all(record["sequence"] == year for record in records):
        for record in records:
            record["sequence"] = None
    return records


def validate(records_by_year: dict[int, list[dict]]) -> None:
    for year, records in records_by_year.items():
        expected_count = KNOWN_EXPECTED_COUNTS.get(year)
        if expected_count is not None and len(records) != expected_count:
            raise ValueError(
                f"Unexpected {year} row count: {len(records)}; "
                f"expected {expected_count}"
            )
        codes = [record["code"] for record in records]
        if len(codes) != len(set(codes)):
            raise ValueError(f"Duplicate codes found in {year}")
        if records and all(record["sequence"] is not None for record in records):
            sequences = [record["sequence"] for record in records]
            if sequences != list(range(1, len(records) + 1)):
                raise ValueError(f"Non-contiguous sequence found in {year}")


def build_payload(source_dir: Path) -> dict:
    year_pdfs = discover_year_pdfs(source_dir)
    years = list(year_pdfs)
    records_by_year: dict[int, list[dict]] = {}
    prior_candidates: dict[str, list[str]] = defaultdict(list)

    for year in years:
        prior_names = {
            code: max(names, key=name_quality)
            for code, names in prior_candidates.items()
        }
        pdf_path = year_pdfs[year]
        records = extract_year(pdf_path, year, prior_names)
        records_by_year[year] = records
        for record in records:
            prior_candidates[record["code"]].append(record["name"])

    validate(records_by_year)
    all_records = [record for year in years for record in records_by_year[year]]
    code_sets = {
        year: {record["code"] for record in records}
        for year, records in records_by_year.items()
    }
    all_codes = set().union(*code_sets.values())
    common_codes = set.intersection(*code_sets.values())
    qa_records = [record for record in all_records if record["flags"]]

    changes = {}
    for previous_year, current_year in zip(years, years[1:]):
        changes[f"{previous_year}to{current_year}"] = {
            "added": sorted(code_sets[current_year] - code_sets[previous_year]),
            "removed": sorted(code_sets[previous_year] - code_sets[current_year]),
        }

    return {
        "meta": {
            "title": "特材功能類別前5碼使用數量分析",
            "years": years,
            "recordCount": len(all_records),
            "uniqueCodeCount": len(all_codes),
            "commonAllYearsCount": len(common_codes),
            "qaRecordCount": len(qa_records),
            "yearCounts": {
                str(year): len(records_by_year[year]) for year in years
            },
            "changes": changes,
            "sources": [
                {
                    "rocYear": year,
                    "file": f"{year}年.pdf",
                    "href": f"/sources/{year}.pdf",
                }
                for year in years
            ],
        },
        "records": all_records,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--source-dir", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()

    payload = build_payload(args.source_dir)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(
        json.dumps(payload, ensure_ascii=False, separators=(",", ":")),
        encoding="utf-8",
    )
    print(
        f"Wrote {payload['meta']['recordCount']} records across "
        f"{len(payload['meta']['years'])} years to {args.output}"
    )


if __name__ == "__main__":
    main()
