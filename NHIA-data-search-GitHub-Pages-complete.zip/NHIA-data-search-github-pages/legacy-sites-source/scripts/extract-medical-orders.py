#!/usr/bin/env python3
"""Normalize NHIA medical-order annual claim counts from CSV for the site."""

from __future__ import annotations

import argparse
import csv
import json
from collections import Counter, defaultdict
from decimal import Decimal, InvalidOperation
from pathlib import Path


REQUIRED_COLUMNS = {
    "費用年",
    "診療項目代碼",
    "中文項目名稱",
    "英文項目名稱",
    "申報量（次）",
}


def parse_quantity(value: str, row_number: int) -> int | float:
    text = value.strip().replace(",", "")
    try:
        quantity = Decimal(text)
    except InvalidOperation as error:
        raise ValueError(f"Invalid quantity on CSV row {row_number}: {value!r}") from error
    if quantity < 0:
        raise ValueError(f"Negative quantity on CSV row {row_number}: {value!r}")
    if quantity == quantity.to_integral_value():
        return int(quantity)
    return float(quantity)


def build_payload(source: Path) -> dict:
    records_by_code: dict[str, list[dict]] = defaultdict(list)
    names_by_code: dict[str, dict[int, tuple[str, str]]] = defaultdict(dict)
    year_counts: Counter[int] = Counter()
    seen_year_codes: set[tuple[int, str]] = set()

    with source.open("r", encoding="utf-8-sig", newline="") as csv_file:
        reader = csv.DictReader(csv_file)
        missing_columns = REQUIRED_COLUMNS - set(reader.fieldnames or [])
        if missing_columns:
            raise ValueError(
                "Missing required CSV columns: " + ", ".join(sorted(missing_columns))
            )

        for row_number, row in enumerate(reader, start=2):
            calendar_year = int(row["費用年"].strip())
            roc_year = calendar_year - 1911
            code = row["診療項目代碼"].strip()
            name = row["中文項目名稱"].strip()
            english_name = row["英文項目名稱"].strip()
            if not code or not name:
                raise ValueError(f"Missing code or Chinese name on CSV row {row_number}")

            year_code = (roc_year, code)
            if year_code in seen_year_codes:
                raise ValueError(
                    f"Duplicate year and code on CSV row {row_number}: {calendar_year}, {code}"
                )
            seen_year_codes.add(year_code)

            records_by_code[code].append(
                {
                    "rocYear": roc_year,
                    "calendarYear": calendar_year,
                    "totalQuantity": parse_quantity(row["申報量（次）"], row_number),
                }
            )
            names_by_code[code][roc_year] = (name, english_name)
            year_counts[roc_year] += 1

    years = sorted(year_counts)
    if not years:
        raise ValueError("CSV contains no records")

    groups = []
    for code in sorted(records_by_code):
        code_records = sorted(records_by_code[code], key=lambda record: record["rocYear"])
        latest_year = code_records[-1]["rocYear"]
        name, english_name = names_by_code[code][latest_year]
        quantity_by_year = {
            record["rocYear"]: record["totalQuantity"] for record in code_records
        }
        groups.append(
            {
                "code": code,
                "name": name,
                "englishName": english_name,
                "quantities": [quantity_by_year.get(year) for year in years],
            }
        )

    return {
        "meta": {
            "title": "診療項目醫令申報量",
            "years": years,
            "calendarYears": [year + 1911 for year in years],
            "recordCount": sum(year_counts.values()),
            "uniqueCodeCount": len(groups),
            "yearCounts": {str(year): year_counts[year] for year in years},
            "sourceFile": source.name,
            "unit": "次",
        },
        "groups": groups,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()

    payload = build_payload(args.source)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(
        json.dumps(payload, ensure_ascii=False, separators=(",", ":")),
        encoding="utf-8",
    )
    print(json.dumps(payload["meta"], ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
