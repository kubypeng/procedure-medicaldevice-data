"use client";

import { useMemo, useState } from "react";
import materialDataset from "./data/materials.json";
import medicalOrderDataset from "./data/medical-orders.json";

type DatabaseKey = "materials" | "medicalOrders";
type YearSystem = "roc" | "calendar";

type MaterialRecord = {
  rocYear: number;
  code: string;
  name: string;
  totalQuantity: number;
};

type QuantityRecord = {
  rocYear: number;
  totalQuantity: number;
};

type CodeGroup = {
  code: string;
  name: string;
  englishName: string;
  records: QuantityRecord[];
  firstYear: number;
  lastYear: number;
};

type MedicalOrderSourceGroup = {
  code: string;
  name: string;
  englishName: string;
  quantities: Array<number | null>;
};

type DatabaseConfig = {
  key: DatabaseKey;
  title: string;
  tabLabel: string;
  searchLabel: string;
  itemLabel: string;
  codeHeader: string;
  nameHeader: string;
  quantityTitle: string;
  unit: string;
  exportPrefix: string;
  placeholderExamples: string[];
  quickSearches: string[];
  noteText: string;
  sourceText: string;
  years: number[];
  groups: CodeGroup[];
};

type ExplorerState = {
  query: string;
  selectedCode: string;
  selectedExportCodes: Set<string>;
  startYear: number;
  endYear: number;
};

const RESULT_RENDER_LIMIT = 300;
const SELECTED_ITEM_DISPLAY_LIMIT = 30;
const FORECAST_END_CALENDAR_YEAR = 2031;
const MEDICAL_ORDER_START_CODE = "33110B";
const numberFormatter = new Intl.NumberFormat("zh-TW", {
  maximumFractionDigits: 1,
});

const materialYears = [...(materialDataset.meta.years as number[])].sort(
  (a, b) => a - b,
);
const medicalOrderYears = [...(medicalOrderDataset.meta.years as number[])].sort(
  (a, b) => a - b,
);

function buildMaterialGroups() {
  const grouped = new Map<string, MaterialRecord[]>();
  for (const record of materialDataset.records as MaterialRecord[]) {
    const existing = grouped.get(record.code) ?? [];
    existing.push(record);
    grouped.set(record.code, existing);
  }
  return Array.from(grouped.entries())
    .map(([code, codeRecords]) => {
      const ordered = [...codeRecords].sort((a, b) => a.rocYear - b.rocYear);
      return {
        code,
        name: ordered.at(-1)?.name ?? code,
        englishName: "",
        records: ordered.map((record) => ({
          rocYear: record.rocYear,
          totalQuantity: record.totalQuantity,
        })),
        firstYear: ordered[0].rocYear,
        lastYear: ordered.at(-1)?.rocYear ?? ordered[0].rocYear,
      };
    })
    .sort((a, b) => a.code.localeCompare(b.code));
}

function buildMedicalOrderGroups() {
  const groups = (medicalOrderDataset.groups as MedicalOrderSourceGroup[])
    .map((group) => {
      const records = group.quantities.flatMap((quantity, index) =>
        quantity === null
          ? []
          : [{ rocYear: medicalOrderYears[index], totalQuantity: quantity }],
      );
      return {
        code: group.code,
        name: group.name,
        englishName: group.englishName,
        records,
        firstYear: records[0].rocYear,
        lastYear: records.at(-1)?.rocYear ?? records[0].rocYear,
      };
    })
    .sort((a, b) => a.code.localeCompare(b.code));

  const startIndex = groups.findIndex(
    (group) => group.code === MEDICAL_ORDER_START_CODE,
  );
  return startIndex < 0
    ? groups
    : [...groups.slice(startIndex), ...groups.slice(0, startIndex)];
}

const materialGroups = buildMaterialGroups();
const medicalOrderGroups = buildMedicalOrderGroups();

const databases: Record<DatabaseKey, DatabaseConfig> = {
  materials: {
    key: "materials",
    title: "特材前5碼申報數量資料庫",
    tabLabel: "特材前5碼申報量",
    searchLabel: "搜尋特材功能類別",
    itemLabel: "類別",
    codeHeader: "前五碼",
    nameHeader: "中文名稱",
    quantityTitle: "特材申報量",
    unit: "筆",
    exportPrefix: "特材前5碼",
    placeholderExamples: ["CBB01", "氣球導管"],
    quickSearches: ["氣球導管", "支架", "引流", "人工關節"],
    noteText: "資料依原始PDF公告內容呈現。",
    sourceText: "資料來源：健保署：特材(功能類別)品項前5碼使用量分析檔案",
    years: materialYears,
    groups: materialGroups,
  },
  medicalOrders: {
    key: "medicalOrders",
    title: "診療項目醫令申報量資料庫",
    tabLabel: "診療項目醫令申報量",
    searchLabel: "搜尋診療項目",
    itemLabel: "項目",
    codeHeader: "診療項目代碼",
    nameHeader: "中文項目名稱",
    quantityTitle: "診療項目醫令申報量",
    unit: "次",
    exportPrefix: "診療項目醫令申報量",
    placeholderExamples: ["68040B", "TAVI"],
    quickSearches: ["經導管", "支架", "疝氣", "脊椎"],
    noteText: "申報量依原始CSV內容呈現；「未收錄」表示該年度檔案中未見該代碼。",
    sourceText: "資料來源：健保署資料開放平台：診療項目醫令申報量(年)",
    years: medicalOrderYears,
    groups: medicalOrderGroups,
  },
};

function initialExplorerState(config: DatabaseConfig, preferredCode?: string): ExplorerState {
  const firstYear = config.years[0];
  const endYear = config.years.at(-1) ?? firstYear;
  const selectedCode = preferredCode && config.groups.some((group) => group.code === preferredCode)
    ? preferredCode
    : config.groups[0].code;
  return {
    query: "",
    selectedCode,
    selectedExportCodes: new Set<string>(),
    startYear: firstYear,
    endYear,
  };
}

function formatNumber(value: number | null | undefined) {
  return value === null || value === undefined ? "—" : numberFormatter.format(value);
}

function displayYear(rocYear: number, yearSystem: YearSystem) {
  return yearSystem === "roc" ? String(rocYear) : String(rocYear + 1911);
}

function normalize(value: string) {
  return value
    .normalize("NFKC")
    .toUpperCase()
    .replace(/[\s"'（）()、，,。./_\-]/g, "");
}

function getSearchTerms(query: string, years: number[]) {
  const yearTokens = new Set(
    years.flatMap((year) => [String(year), String(year + 1911)]),
  );
  const cleaned = query.replace(
    /申報數量|使用數量|申報量|使用量|近三年|三年度|請幫我|幫我|我想看|查詢|搜尋|查找|比較|顯示|列出|分析|新收錄|未收錄|新增|移除|消失|未見|醫令|年度|資料|變化|趨勢|數量|民國|西元|的|年/gi,
    " ",
  );
  return cleaned
    .split(/[\s，,、]+/)
    .filter((term) => term && !yearTokens.has(term))
    .map(normalize)
    .filter(Boolean);
}

function findMentionedYear(query: string, years: number[]) {
  const numericTokens = query.match(/\d+/g) ?? [];
  return years.find(
    (year) =>
      numericTokens.includes(String(year)) ||
      numericTokens.includes(String(year + 1911)),
  );
}

function fuzzyContains(haystack: string, needle: string) {
  if (haystack.includes(needle)) return true;
  if (needle.length < 2) return false;
  let needleIndex = 0;
  for (const character of haystack) {
    if (character === needle[needleIndex]) needleIndex += 1;
    if (needleIndex === needle.length) return true;
  }
  return false;
}

function filterGroups(groups: CodeGroup[], query: string, years: number[]) {
  const latestYear = years.at(-1) ?? years[0];
  const normalizedQuery = normalize(query);
  if (!normalizedQuery) return groups;

  const terms = getSearchTerms(query, years);
  const wantsAdded = /新增|新收錄/.test(query);
  const wantsRemoved = /移除|消失|未見|未收錄/.test(query);
  const mentionedYear = findMentionedYear(query, years);

  return groups
    .map((group) => {
      const haystack = normalize(`${group.code} ${group.name} ${group.englishName}`);
      let score = 0;

      if (wantsAdded && group.firstYear !== (mentionedYear ?? latestYear)) return null;
      if (wantsRemoved && group.lastYear >= (mentionedYear ?? latestYear)) return null;
      if (
        mentionedYear &&
        !wantsRemoved &&
        !group.records.some((record) => record.rocYear === mentionedYear)
      ) {
        return null;
      }

      if (!normalizedQuery || terms.length === 0) score = 1;
      if (normalize(group.code) === normalizedQuery) score += 120;
      if (normalize(group.code).includes(normalizedQuery)) score += 90;
      if (terms.length && terms.every((term) => haystack.includes(term))) score += 70;
      else if (terms.length && terms.every((term) => fuzzyContains(haystack, term))) score += 48;
      if (terms.some((term) => haystack.includes(term))) score += 35;
      else if (terms.some((term) => fuzzyContains(haystack, term))) score += 20;
      if (!score) return null;
      return { group, score };
    })
    .filter((item): item is { group: CodeGroup; score: number } => item !== null)
    .sort((a, b) => b.score - a.score || a.group.code.localeCompare(b.group.code))
    .map((item) => item.group);
}

function SearchIcon() {
  return (
    <svg viewBox="0 0 24 24" aria-hidden="true">
      <circle cx="11" cy="11" r="6.8" />
      <path d="m16.1 16.1 4.1 4.1" />
    </svg>
  );
}

function DownloadIcon() {
  return (
    <svg viewBox="0 0 24 24" aria-hidden="true">
      <path d="M12 3v11m0 0 4-4m-4 4-4-4M5 18v2h14v-2" />
    </svg>
  );
}

function csvCell(value: string | number | null | undefined) {
  if (value === null || value === undefined) return "";
  const text = String(value);
  return `"${text.replaceAll('"', '""')}"`;
}

function safeFilePart(value: string) {
  return value.replace(/[\\/:*?"<>|]/g, "_").trim().slice(0, 40);
}

function TrendChart({
  group,
  displayYears,
  yearSystem,
  records = group.records,
  seriesLabel = "申報數量趨勢",
  fillId = "trend-fill",
  variant = "actual",
}: {
  group: CodeGroup;
  displayYears: number[];
  yearSystem: YearSystem;
  records?: QuantityRecord[];
  seriesLabel?: string;
  fillId?: string;
  variant?: "actual" | "forecast";
}) {
  const width = 920;
  const height = 238;
  const paddingX = 52;
  const paddingTop = 26;
  const paddingBottom = 44;
  const recordMap = new Map(records.map((record) => [record.rocYear, record]));
  const values = displayYears.map((year) => recordMap.get(year)?.totalQuantity ?? null);
  const maxValue = Math.max(...values.filter((value): value is number => value !== null), 1);
  const chartHeight = height - paddingTop - paddingBottom;
  const chartWidth = width - paddingX * 2;
  const points = values.map((value, index) => ({
    value,
    x:
      displayYears.length === 1
        ? width / 2
        : paddingX + (chartWidth * index) / (displayYears.length - 1),
    y:
      value === null
        ? height - paddingBottom
        : paddingTop + chartHeight - (value / maxValue) * chartHeight,
  }));
  const availablePoints = points.filter(
    (point): point is typeof point & { value: number } => point.value !== null,
  );
  const linePath = availablePoints
    .map((point, index) => `${index === 0 ? "M" : "L"}${point.x},${point.y}`)
    .join(" ");
  const areaPath = availablePoints.length > 1
    ? `${linePath} L${availablePoints.at(-1)?.x},${height - paddingBottom} L${availablePoints[0].x},${height - paddingBottom} Z`
    : "";
  const chartColor = variant === "forecast" ? "#008f77" : "#0a5694";

  return (
    <div className={`trend-chart ${variant}-trend-chart`}>
      <svg
        viewBox={`0 0 ${width} ${height}`}
        role="img"
        aria-label={`${group.code} ${displayYear(displayYears[0], yearSystem)}年至${displayYear(displayYears.at(-1) ?? displayYears[0], yearSystem)}年${seriesLabel}`}
      >
        <defs>
          <linearGradient id={fillId} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor={chartColor} stopOpacity="0.25" />
            <stop offset="100%" stopColor={chartColor} stopOpacity="0" />
          </linearGradient>
        </defs>
        {[0, 0.5, 1].map((ratio) => {
          const y = paddingTop + chartHeight * ratio;
          return (
            <line
              key={ratio}
              x1={paddingX}
              x2={width - paddingX}
              y1={y}
              y2={y}
              className="chart-grid"
            />
          );
        })}
        {areaPath ? <path d={areaPath} fill={`url(#${fillId})`} /> : null}
        {availablePoints.length > 1 ? <path d={linePath} className="chart-line" /> : null}
        {points.map((point, index) => (
          <g key={displayYears[index]}>
            {point.value !== null ? (
              <>
                <circle cx={point.x} cy={point.y} r="5.5" className="chart-point" />
                <text x={point.x} y={point.y - 15} className="chart-value">
                  {formatNumber(point.value)}
                </text>
              </>
            ) : (
              <text
                x={point.x}
                y={height - paddingBottom - 14}
                className="chart-missing"
              >
                未收錄
              </text>
            )}
            <text x={point.x} y={height - 15} className="chart-year">
              {displayYear(displayYears[index], yearSystem)}年
            </text>
          </g>
        ))}
      </svg>
    </div>
  );
}

function calculateCagr(group: CodeGroup, selectedYears: number[]) {
  const startYear = selectedYears[0];
  const endYear = selectedYears.at(-1) ?? startYear;
  if (selectedYears.length < 2 || startYear === endYear) {
    return { startYear, endYear, value: null, reason: "至少選擇兩個年度" };
  }

  const byYear = new Map(group.records.map((record) => [record.rocYear, record]));
  const startValue = byYear.get(startYear)?.totalQuantity;
  const endValue = byYear.get(endYear)?.totalQuantity;
  if (startValue === undefined || endValue === undefined) {
    return { startYear, endYear, value: null, reason: "起始與結束年度都須有資料" };
  }
  if (startValue <= 0) {
    return { startYear, endYear, value: null, reason: "起始年度數量須大於 0" };
  }

  const periods = endYear - startYear;
  const value = Math.pow(endValue / startValue, 1 / periods) - 1;
  return { startYear, endYear, startValue, endValue, value, reason: "" };
}

function buildForecast(
  cagr: ReturnType<typeof calculateCagr>,
  calendarYears: number[],
) {
  if (cagr.value === null || cagr.endValue === undefined) return [];
  const baseCalendarYear = cagr.endYear + 1911;
  return calendarYears.map((calendarYear) => {
    const periods = calendarYear - baseCalendarYear;
    const rawValue = cagr.endValue * Math.pow(1 + cagr.value, periods);
    const value = Math.round(rawValue);
    return {
      calendarYear,
      rocYear: calendarYear - 1911,
      value: Number.isFinite(value) ? Math.max(0, value) : null,
    };
  });
}

export default function ExplorerPage() {
  const [activeDatabase, setActiveDatabase] = useState<DatabaseKey>("materials");
  const [yearSystem, setYearSystem] = useState<YearSystem>("roc");
  const [stateByDatabase, setStateByDatabase] = useState<
    Record<DatabaseKey, ExplorerState>
  >(() => ({
    materials: initialExplorerState(databases.materials, "CBB01"),
    medicalOrders: initialExplorerState(
      databases.medicalOrders,
      MEDICAL_ORDER_START_CODE,
    ),
  }));

  const config = databases[activeDatabase];
  const explorerState = stateByDatabase[activeDatabase];
  const firstDatasetYear = config.years[0];
  const latestDatasetYear = config.years.at(-1) ?? firstDatasetYear;
  const forecastCalendarYears = useMemo(() => {
    const firstForecastCalendarYear = latestDatasetYear + 1912;
    return Array.from(
      {
        length: Math.max(
          FORECAST_END_CALENDAR_YEAR - firstForecastCalendarYear + 1,
          0,
        ),
      },
      (_, index) => firstForecastCalendarYear + index,
    );
  }, [latestDatasetYear]);
  const selectedYears = useMemo(
    () =>
      config.years.filter(
        (year) => year >= explorerState.startYear && year <= explorerState.endYear,
      ),
    [config.years, explorerState.startYear, explorerState.endYear],
  );
  const filteredGroups = useMemo(
    () => filterGroups(config.groups, explorerState.query, config.years),
    [config.groups, config.years, explorerState.query],
  );
  const visibleGroups = filteredGroups.slice(0, RESULT_RENDER_LIMIT);
  const selectedExportGroups = useMemo(() => {
    const groupsByCode = new Map(
      config.groups.map((group) => [group.code, group] as const),
    );
    return Array.from(explorerState.selectedExportCodes).flatMap((code) => {
      const group = groupsByCode.get(code);
      return group ? [group] : [];
    });
  }, [config.groups, explorerState.selectedExportCodes]);
  const selectedGroup =
    config.groups.find((group) => group.code === explorerState.selectedCode) ??
    config.groups[0];
  const cagr = calculateCagr(selectedGroup, selectedYears);
  const forecast = buildForecast(cagr, forecastCalendarYears);
  const forecastRecords = forecast.flatMap((point) =>
    point.value === null
      ? []
      : [{ rocYear: point.rocYear, totalQuantity: point.value }],
  );
  const allFilteredSelected =
    filteredGroups.length > 0 &&
    filteredGroups.every((group) => explorerState.selectedExportCodes.has(group.code));

  function updateExplorerState(patch: Partial<ExplorerState>) {
    setStateByDatabase((current) => ({
      ...current,
      [activeDatabase]: {
        ...current[activeDatabase],
        ...patch,
      },
    }));
  }

  function updateExportCodes(updater: (current: Set<string>) => Set<string>) {
    setStateByDatabase((current) => {
      const currentState = current[activeDatabase];
      return {
        ...current,
        [activeDatabase]: {
          ...currentState,
          selectedExportCodes: updater(currentState.selectedExportCodes),
        },
      };
    });
  }

  function chooseFirstResult() {
    if (filteredGroups[0]) {
      updateExplorerState({ selectedCode: filteredGroups[0].code });
    }
  }

  function toggleExportSelection(code: string) {
    updateExportCodes((current) => {
      const next = new Set(current);
      if (next.has(code)) next.delete(code);
      else next.add(code);
      return next;
    });
  }

  function toggleAllFilteredResults() {
    updateExportCodes((current) => {
      const next = new Set(current);
      if (allFilteredSelected) {
        filteredGroups.forEach((group) => next.delete(group.code));
      } else {
        filteredGroups.forEach((group) => next.add(group.code));
      }
      return next;
    });
  }

  function exportCurrentResults() {
    const exportGroups = explorerState.selectedExportCodes.size
      ? config.groups.filter((group) => explorerState.selectedExportCodes.has(group.code))
      : filteredGroups;
    const startYearLabel = displayYear(explorerState.startYear, yearSystem);
    const endYearLabel = displayYear(explorerState.endYear, yearSystem);
    const header = [
      config.codeHeader,
      config.nameHeader,
      ...selectedYears.map((year) => `${displayYear(year, yearSystem)}年`),
      `${explorerState.endYear - explorerState.startYear}年CAGR (${startYearLabel}年至${endYearLabel}年)`,
      ...forecastCalendarYears.map(
        (calendarYear) =>
          `${displayYear(calendarYear - 1911, yearSystem)}年推估`,
      ),
    ];
    const rows = exportGroups.map((group) => {
      const byYear = new Map(group.records.map((record) => [record.rocYear, record]));
      const groupCagr = calculateCagr(group, selectedYears);
      const groupForecast = buildForecast(groupCagr, forecastCalendarYears);
      const forecastValues = groupForecast.length
        ? groupForecast.map((point) => point.value ?? "")
        : forecastCalendarYears.map(() => "");
      return [
        group.code,
        group.name.replace(/^"|"$/g, ""),
        ...selectedYears.map((year) => byYear.get(year)?.totalQuantity),
        groupCagr.value === null ? "" : `${(groupCagr.value * 100).toFixed(2)}%`,
        ...forecastValues,
      ];
    });
    const csv = [header, ...rows]
      .map((row) => row.map((value) => csvCell(value)).join(","))
      .join("\r\n");
    const blob = new Blob(["\uFEFF", csv], { type: "text/csv;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    const yearRange = `${startYearLabel}-${endYearLabel}年`;
    const queryFilePart = safeFilePart(explorerState.query);
    link.download = explorerState.selectedExportCodes.size
      ? `${config.exportPrefix}_已選${explorerState.selectedExportCodes.size}項_${yearRange}.csv`
      : queryFilePart
        ? `${config.exportPrefix}_${queryFilePart}_${yearRange}.csv`
        : `${config.exportPrefix}_${yearRange}.csv`;
    link.style.display = "none";
    document.body.appendChild(link);
    link.click();
    link.remove();
    window.setTimeout(() => URL.revokeObjectURL(url), 0);
  }

  const searchInputId = `${activeDatabase}-search`;

  return (
    <main className="site-shell">
      <header className="topbar">
        <div className="brand">
          <strong>{config.title}</strong>
        </div>
        <div className="topbar-actions">
          <button
            className="export-button"
            onClick={exportCurrentResults}
            disabled={
              explorerState.selectedExportCodes.size === 0 && filteredGroups.length === 0
            }
          >
            <DownloadIcon />
            {explorerState.selectedExportCodes.size
              ? `匯出已選 ${explorerState.selectedExportCodes.size} 項`
              : "匯出目前結果"}
          </button>
        </div>
      </header>

      <section className="database-switcher" aria-label="選擇資料庫與年份顯示方式">
        <nav className="database-tabs" aria-label="資料庫分頁">
          {(Object.keys(databases) as DatabaseKey[]).map((databaseKey) => (
            <button
              key={databaseKey}
              type="button"
              className={activeDatabase === databaseKey ? "active" : ""}
              aria-current={activeDatabase === databaseKey ? "page" : undefined}
              onClick={() => setActiveDatabase(databaseKey)}
            >
              {databases[databaseKey].tabLabel}
            </button>
          ))}
        </nav>
        <div className="year-display-control">
          <span>年份顯示</span>
          <div className="year-system-toggle" role="group" aria-label="切換年份顯示方式">
            <button
              type="button"
              className={yearSystem === "roc" ? "active" : ""}
              aria-pressed={yearSystem === "roc"}
              onClick={() => setYearSystem("roc")}
            >
              民國
            </button>
            <button
              type="button"
              className={yearSystem === "calendar" ? "active" : ""}
              aria-pressed={yearSystem === "calendar"}
              onClick={() => setYearSystem("calendar")}
            >
              西元
            </button>
          </div>
        </div>
      </section>

      <section className="search-area" id="database-content">
        <div className="search-panel">
          <label htmlFor={searchInputId}>{config.searchLabel}</label>
          <div className="search-box">
            <SearchIcon />
            <input
              id={searchInputId}
              value={explorerState.query}
              onChange={(event) => updateExplorerState({ query: event.target.value })}
              onKeyDown={(event) => {
                if (event.key === "Enter") chooseFirstResult();
              }}
              placeholder={`例如：${config.placeholderExamples.join("、")}`}
              autoComplete="off"
            />
            {explorerState.query ? (
              <button
                className="clear-button"
                onClick={() => updateExplorerState({ query: "" })}
                aria-label="清除搜尋"
              >
                清除
              </button>
            ) : null}
            <button className="search-button" onClick={chooseFirstResult}>
              搜尋
            </button>
          </div>
          <div className="quick-searches">
            <span>快速搜尋</span>
            {config.quickSearches.map((term) => (
              <button key={term} onClick={() => updateExplorerState({ query: term })}>
                {term}
              </button>
            ))}
          </div>
        </div>
      </section>

      <section className="year-filter" aria-label="選擇比較年度">
        <div className="year-filter-heading">
          <span>比較年度</span>
          <strong>輸入起始與結束年度</strong>
        </div>
        <div className="year-range-controls">
          <label>
            <span>起始年度</span>
            <select
              value={explorerState.startYear}
              onChange={(event) =>
                updateExplorerState({ startYear: Number(event.target.value) })
              }
            >
              {config.years
                .filter((year) => year < explorerState.endYear)
                .map((year) => (
                  <option key={year} value={year}>
                    {displayYear(year, yearSystem)}年
                  </option>
                ))}
            </select>
          </label>
          <span className="range-separator">至</span>
          <label>
            <span>結束年度</span>
            <select
              value={explorerState.endYear}
              onChange={(event) =>
                updateExplorerState({ endYear: Number(event.target.value) })
              }
            >
              {config.years
                .filter((year) => year > explorerState.startYear)
                .map((year) => (
                  <option key={year} value={year}>
                    {displayYear(year, yearSystem)}年
                  </option>
                ))}
            </select>
          </label>
        </div>
        <button
          type="button"
          className="select-all-years"
          disabled={
            explorerState.startYear === firstDatasetYear &&
            explorerState.endYear === latestDatasetYear
          }
          onClick={() =>
            updateExplorerState({
              startYear: firstDatasetYear,
              endYear: latestDatasetYear,
            })
          }
        >
          顯示全部年度
        </button>
      </section>

      <section className="workspace">
        <aside className="result-panel">
          <div className="panel-heading">
            <div>
              <span>搜尋結果</span>
              <strong>
                {numberFormatter.format(filteredGroups.length)} 個{config.itemLabel}
              </strong>
            </div>
            {explorerState.query ? (
              <small>「{explorerState.query}」</small>
            ) : (
              <small>全部{config.itemLabel}</small>
            )}
          </div>

          <div className="result-selection-bar">
            <span>
              已選 {" "}
              <strong>
                {numberFormatter.format(explorerState.selectedExportCodes.size)}
              </strong>{" "}
              個{config.itemLabel}
            </span>
            <div>
              <button
                type="button"
                onClick={toggleAllFilteredResults}
                disabled={filteredGroups.length === 0}
              >
                {allFilteredSelected ? "取消全選" : "全選目前結果"}
              </button>
              <button
                type="button"
                onClick={() =>
                  updateExplorerState({ selectedExportCodes: new Set<string>() })
                }
                disabled={explorerState.selectedExportCodes.size === 0}
              >
                清除選取
              </button>
            </div>
          </div>

          {selectedExportGroups.length ? (
            <div className="selected-items-panel">
              <span className="selected-items-label">已選項目</span>
              <div className="selected-items-list">
                {selectedExportGroups
                  .slice(0, SELECTED_ITEM_DISPLAY_LIMIT)
                  .map((group) => (
                    <button
                      key={group.code}
                      type="button"
                      className="selected-item"
                      onClick={() => toggleExportSelection(group.code)}
                      title={`取消選取 ${group.code} ${group.name.replace(/^"|"$/g, "")}`}
                      aria-label={`取消選取 ${group.code}`}
                    >
                      <code>{group.code}</code>
                      <span>{group.name.replace(/^"|"$/g, "")}</span>
                      <b aria-hidden="true">×</b>
                    </button>
                  ))}
              </div>
              {selectedExportGroups.length > SELECTED_ITEM_DISPLAY_LIMIT ? (
                <small>
                  另有 {numberFormatter.format(
                    selectedExportGroups.length - SELECTED_ITEM_DISPLAY_LIMIT,
                  )} 個項目已選取
                </small>
              ) : null}
            </div>
          ) : null}

          <div className="result-list">
            {visibleGroups.length ? (
              <>
                {visibleGroups.map((group) => {
                  const isExportSelected = explorerState.selectedExportCodes.has(
                    group.code,
                  );
                  return (
                    <div
                      key={group.code}
                      className={`result-row ${selectedGroup.code === group.code ? "selected" : ""} ${isExportSelected ? "marked" : ""}`}
                    >
                      <input
                        className="result-checkbox"
                        type="checkbox"
                        checked={isExportSelected}
                        onChange={() => toggleExportSelection(group.code)}
                        aria-label={`選取 ${group.code} 匯出`}
                      />
                      <button
                        type="button"
                        className="result-row-content"
                        onClick={() => updateExplorerState({ selectedCode: group.code })}
                      >
                        <div className="result-code-line">
                          <code>{group.code}</code>
                        </div>
                        <strong>{group.name.replace(/^"|"$/g, "")}</strong>
                      </button>
                    </div>
                  );
                })}
                {filteredGroups.length > RESULT_RENDER_LIMIT ? (
                  <div className="result-limit-note">
                    目前顯示前 {numberFormatter.format(RESULT_RENDER_LIMIT)} 個結果；請輸入代碼或關鍵字縮小範圍。
                  </div>
                ) : null}
              </>
            ) : (
              <div className="no-results">
                <strong>找不到符合的{config.itemLabel}</strong>
                <p>可改用較短的中文關鍵字或代碼搜尋。</p>
                <button onClick={() => updateExplorerState({ query: "" })}>
                  查看全部{config.itemLabel}
                </button>
              </div>
            )}
          </div>
        </aside>

        <article className="detail-panel">
          <header className="detail-heading">
            <div>
              <div className="detail-code-line">
                <code>{selectedGroup.code}</code>
              </div>
              <h2>{selectedGroup.name.replace(/^"|"$/g, "")}</h2>
              {selectedGroup.englishName ? (
                <p className="detail-english-name">{selectedGroup.englishName}</p>
              ) : null}
            </div>
          </header>

          <section className="insight-grid">
            <article className="chart-card">
              <div className="section-heading">
                <div>
                  <span>年度趨勢</span>
                  <h3>{config.quantityTitle}</h3>
                </div>
                <small>單位：{config.unit}</small>
              </div>
              <TrendChart
                group={selectedGroup}
                displayYears={selectedYears}
                yearSystem={yearSystem}
              />
            </article>

            <article className="cagr-card">
              <div className="section-heading">
                <div>
                  <span>年複合成長率</span>
                  <h3>
                    {cagr.endYear - cagr.startYear}年CAGR
                    <small>
                      ({displayYear(cagr.startYear, yearSystem)}年至
                      {displayYear(cagr.endYear, yearSystem)}年)
                    </small>
                  </h3>
                </div>
              </div>
              {cagr.value === null ? (
                <div className="cagr-empty">
                  <strong>—</strong>
                  <p>{cagr.reason}</p>
                </div>
              ) : (
                <div className="cagr-result">
                  <strong className={cagr.value >= 0 ? "positive" : "negative"}>
                    {cagr.value >= 0 ? "+" : ""}
                    {(cagr.value * 100).toFixed(2)}%
                  </strong>
                  <dl>
                    <div>
                      <dt>{displayYear(cagr.startYear, yearSystem)}年</dt>
                      <dd>{formatNumber(cagr.startValue)}</dd>
                    </div>
                    <div>
                      <dt>{displayYear(cagr.endYear, yearSystem)}年</dt>
                      <dd>{formatNumber(cagr.endValue)}</dd>
                    </div>
                  </dl>
                </div>
              )}
              <div className="cagr-note">
                依起始與結束年度計算；趨勢圖會自動顯示中間所有年份。
              </div>
            </article>

            <article className="forecast-card">
              <div className="section-heading">
                <div>
                  <span>CAGR 延伸推估</span>
                  <h3>
                    {displayYear(forecastCalendarYears[0] - 1911, yearSystem)}–
                    {displayYear(
                      (forecastCalendarYears.at(-1) ?? forecastCalendarYears[0]) - 1911,
                      yearSystem,
                    )}年申報量推估
                  </h3>
                </div>
                <small>單位：{config.unit}</small>
              </div>
              {forecast.length ? (
                <TrendChart
                  group={selectedGroup}
                  displayYears={forecast.map((point) => point.rocYear)}
                  yearSystem={yearSystem}
                  records={forecastRecords}
                  seriesLabel="CAGR申報量推估趨勢"
                  fillId="forecast-fill"
                  variant="forecast"
                />
              ) : (
                <div className="forecast-empty">
                  <strong>目前無法推估</strong>
                  <p>{cagr.reason}</p>
                </div>
              )}
              <div className="forecast-note">
                {cagr.value === null
                  ? "需先取得有效 CAGR 才能推估後續年度。"
                  : `以${displayYear(cagr.endYear, yearSystem)}年申報量為基準，依所選年度區間的 CAGR 推估預測申報量，並自現有資料的下一年度開始顯示。推估量皆取整數；僅供情境估算，不代表官方預測。`}
              </div>
            </article>
          </section>
        </article>
      </section>

      <footer>
        <p>{config.sourceText}</p>
        <span>{config.noteText}</span>
      </footer>
    </main>
  );
}
