import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  metadataBase: new URL("https://nhia-material-search.kubypeng.chatgpt.site"),
  title: "特材前5碼申報數量資料庫",
  description: "搜尋特材前五碼與診療項目代碼，跨年度比較申報量、趨勢與 CAGR。",
  openGraph: {
    title: "特材前5碼申報數量資料庫",
    description: "特材前五碼與診療項目跨年度搜尋、趨勢比較與 CAGR 分析。",
    type: "website",
    url: "/",
    images: [{ url: "/og.png", width: 1200, height: 630 }],
  },
  twitter: {
    card: "summary_large_image",
    title: "特材前5碼申報數量資料庫",
    description: "特材前五碼與診療項目跨年度搜尋、趨勢比較與 CAGR 分析。",
    images: ["/og.png"],
  },
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="zh-Hant">
      <body>{children}</body>
    </html>
  );
}
